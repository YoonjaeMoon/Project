new fullpage('#fullpage', {
    autoScrolling: true,
    scrollHorizontally: true,
    responsiveWidth: 900,
    afterResponsive: function(isResponsive){
    }
});

